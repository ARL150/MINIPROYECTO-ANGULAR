export const carouselImages = [
  { src: '../img/CARRUSEL/1.png' },
  { src: '../img/CARRUSEL/2.png' },
  { src: '../img/CARRUSEL/3.png' },
  { src: '../img/CARRUSEL/4.png' },
  { src: '../img/CARRUSEL/5.png' },
  { src: '../img/CARRUSEL/6.png' }
  ];
  